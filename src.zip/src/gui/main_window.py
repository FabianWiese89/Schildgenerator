import os
import tkinter as tk

from PIL import Image, ImageTk
from tkinter import filedialog, messagebox, ttk
from src.gui.release_notes_window import ReleaseNotesWindow
from src.gui.handbuch_window import HandbuchWindow
from src.gui.single_tab import build_single_tab
from src.services import open_support_email

from src.utils import (
    get_line_count_from_layout,
    resource_path,
    is_single_pdf_valid,
    is_batch_pdf_valid,
)

from src.pdf import (
    generate_pdf_einzeln,
    generate_batch_pdf,
)

from src.config import (
    BG_COLOR,
    BUTTON_COLOR,
    BUTTON_TEXT_COLOR,
    NOTEBOOK_SELECTED_TAB_COLOR,
    ENTRY_TEXT_COLOR,
    ENTRY_CURSOR_COLOR,
    GUI_LOGO_PATH,
    GUI_LOGO_WIDTH,
    GUI_LOGO_HEIGHT,
    GUI_LOGO_RELX,
    GUI_LOGO_RELY,
    GUI_LOGO_ANCHOR,
    MAIN_WINDOW_GEOMETRY,
    SEPARATOR_COLOR,
    VERSION_LABEL_TEXT,
    FONT_TAB,
    FONT_TITLE,
    FONT_LABEL,
    FONT_VERSION,
    FONT_VERSION_HOVER,
    FONT_HINT,
    HINT_TEXT_COLOR,
    APP_WINDOW_TITLE,
    TAB_SINGLE_TITLE,
    TAB_BATCH_TITLE,
    STATUS_TEXT_COLOR,
    VERSION_TEXT_COLOR,
    VERSION_HOVER_TEXT_COLOR,
    LAYOUT_OPTION_DEFAULT,
    LAYOUT_OPTIONS,
    BATCH_TAB_TITLE_TEXT,
    BATCH_LAYOUT_LABEL_TEXT,
    BATCH_EXCEL_LABEL_TEXT,
    BATCH_OUTPUT_LABEL_TEXT,
    BUTTON_BROWSE_TEXT,
    BUTTON_CREATE_PDF_TEXT,
    BUTTON_SUPPORT_TEXT,
    BUTTON_MANUAL_TEXT,
    STATUS_READY_TEXT,
    STATUS_CREATING_PDF_TEXT,
    STATUS_DONE_TEXT,
    MESSAGEBOX_DONE_TITLE,
    MESSAGEBOX_PDF_CREATED_TEXT,
    PDF_DEFAULT_EXTENSION,
    PDF_FILE_TYPE_LABEL,
    PDF_FILE_PATTERN,
    EXCEL_DIALOG_TITLE,
    EXCEL_FILE_TYPE_LABEL,
    EXCEL_FILE_PATTERN,
    BATCH_HINT_NO_HEADER_TEXT,
    BATCH_HINT_COLUMN_A_TEXT,
    BATCH_HINT_COLUMN_B_TEXT,
)
# ==== HAUPTFENSTER ====
class QRCodeGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_WINDOW_TITLE)
        self.root.geometry(MAIN_WINDOW_GEOMETRY)
        self.root.resizable(False, False)
        self.root.configure(bg=BG_COLOR)

        # Tabs
        style = ttk.Style()
        style.theme_use('default')
        style.configure('TNotebook.Tab', background=BG_COLOR, font=FONT_TAB, padding=[16, 6])
        style.map('TNotebook.Tab', background=[('selected', NOTEBOOK_SELECTED_TAB_COLOR)])

        self.notebook = ttk.Notebook(root)
        self.tab_single = tk.Frame(self.notebook, bg=BG_COLOR)
        self.tab_batch = tk.Frame(self.notebook, bg=BG_COLOR)
        self.notebook.add(self.tab_single, text=TAB_SINGLE_TITLE)
        self.notebook.add(self.tab_batch, text=TAB_BATCH_TITLE)
        self.notebook.pack(fill="both", expand=True, padx=40, pady=28)

        # Trennstrich unter den Tabs
        separator = tk.Frame(root, bg=SEPARATOR_COLOR, height=2)
        separator.pack(fill="x", padx=30, pady=(0, 8))

        self.notebook.select(0)  # Einzelerstellung ist Standard

        self.init_single_variables()
        self.init_batch_variables()

        self.build_tab_single()
        self.build_tab_batch()
        self.build_version_label()

    # ==== VERSIONSLABEL UND RELEASE NOTES ====
    def build_version_label(self):
        frame = tk.Frame(self.root, bg=BG_COLOR)
        frame.place(relx=0, rely=1.0, anchor="sw", x=12, y=-8)

        self.version_lbl = tk.Label(
            frame,
            text=VERSION_LABEL_TEXT,
            fg=VERSION_TEXT_COLOR,
            bg=BG_COLOR,
            font=FONT_VERSION,
            cursor="arrow"
        )
        self.version_lbl.pack(anchor="sw")
        self.version_lbl.bind("<Enter>", self._on_version_hover)
        self.version_lbl.bind("<Leave>", self._on_version_leave)
        self.version_lbl.bind("<Button-1>", self.show_release_notes)

    def _on_version_hover(self, event):
        self.version_lbl.config(fg=VERSION_HOVER_TEXT_COLOR, font=FONT_VERSION_HOVER, cursor="hand2")

    def _on_version_leave(self, event):
        self.version_lbl.config(fg=VERSION_TEXT_COLOR, font=FONT_VERSION, cursor="arrow")

    def show_release_notes(self, event=None):
        ReleaseNotesWindow(self.root)

    # ==== ALLGEMEINE GUI-HILFSMETHODEN ====
    def add_logo_to_frame(self, frame):
        logo_path = resource_path(GUI_LOGO_PATH)

        if os.path.exists(logo_path):
            img = Image.open(logo_path)
            img = img.resize((GUI_LOGO_WIDTH, GUI_LOGO_HEIGHT), Image.LANCZOS)
            logo_img = ImageTk.PhotoImage(img)

            logo_label = tk.Label(frame, image=logo_img, bg=BG_COLOR)
            logo_label.image = logo_img
            logo_label.place(
                relx=GUI_LOGO_RELX,
                rely=GUI_LOGO_RELY,
                anchor=GUI_LOGO_ANCHOR,
            )

    def add_handbook_button(self, frame):
        tk.Button(
            frame,
            text=BUTTON_MANUAL_TEXT,
            command=self.show_handbuch,
            bg=BUTTON_COLOR,
            fg=BUTTON_TEXT_COLOR,
            relief="raised"
        ).place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-10)

    def add_support_button(self, frame):
        tk.Button(
            frame,
            text=BUTTON_SUPPORT_TEXT,
            command=self.open_email,
            bg=BUTTON_COLOR,
            fg=BUTTON_TEXT_COLOR,
            padx=18,
            pady=5
        ).pack(side="left", padx=(0, 20))

    def add_browse_button(self, frame, command, row):
        tk.Button(
            frame,
            text=BUTTON_BROWSE_TEXT,
            command=command,
            bg=BUTTON_COLOR,
            fg=BUTTON_TEXT_COLOR
        ).grid(row=row, column=1, padx=10)

    def add_layout_combobox(self, frame, variable, row, pady):
        layout_dropdown = ttk.Combobox(
            frame,
            textvariable=variable,
            values=LAYOUT_OPTIONS,
            state="readonly",
            width=30
        )
        layout_dropdown.grid(row=row, column=0, sticky="w", pady=pady)
        return layout_dropdown

    def add_create_pdf_button(self, frame, command):
        return tk.Button(
            frame,
            text=BUTTON_CREATE_PDF_TEXT,
            command=command,
            bg=BUTTON_COLOR,
            fg=BUTTON_TEXT_COLOR,
            state="disabled",
            padx=20,
            pady=8
        )

    def init_single_variables(self):
        self.single_lagerplatz = tk.StringVar()
        self.single_layout = tk.StringVar(value=LAYOUT_OPTION_DEFAULT)
        self.single_output = tk.StringVar()
        self.single_status = None
        self.single_btn_pdf = None

    def add_status_label(self, frame):
        return tk.Label(
            frame,
            text=STATUS_READY_TEXT,
            fg=STATUS_TEXT_COLOR,
            bg=BG_COLOR
        )

    def add_text_entry(self, frame, variable, row, width):
        entry = tk.Entry(
            frame,
            textvariable=variable,
            width=width,
            bg=BG_COLOR,
            fg=ENTRY_TEXT_COLOR,
            insertbackground=ENTRY_CURSOR_COLOR
        )
        entry.grid(row=row, column=0, sticky="w")
        return entry

    # ==== EINZELERSTELLUNG ====
    def build_tab_single(self):
        build_single_tab(self)

    def update_single_button(self):
        lagerplatz = self.single_lagerplatz.get().strip()
        pdf = self.single_output.get().strip()
        layout = self.single_layout.get()
        if is_single_pdf_valid(lagerplatz, pdf, layout):
            self.single_btn_pdf.config(state="normal")
        else:
            self.single_btn_pdf.config(state="disabled")

    def single_save_pdf(self):
        path = filedialog.asksaveasfilename(
            defaultextension=PDF_DEFAULT_EXTENSION,
            filetypes=[(PDF_FILE_TYPE_LABEL, PDF_FILE_PATTERN)]
        )
        if path:
            self.single_output.set(path)
            self.update_single_button()

    def on_single_generate(self):
        self.single_status.config(text=STATUS_CREATING_PDF_TEXT)
        self.root.update_idletasks()
        choice = get_line_count_from_layout(self.single_layout.get())
        lagerplatz_sys = self.single_lagerplatz.get().strip()
        lagerplatz_vis = lagerplatz_sys.replace("-", " ")
        qr_data = lagerplatz_sys

        output = self.single_output.get().strip()
        if choice == 4:
            generate_pdf_einzeln(lagerplatz_vis, qr_data, output, 4)
        else:
            generate_pdf_einzeln(lagerplatz_vis, qr_data, output, 5)
        self.single_status.config(text=STATUS_DONE_TEXT)
        messagebox.showinfo(
            MESSAGEBOX_DONE_TITLE,
            f"{MESSAGEBOX_PDF_CREATED_TEXT}\n{output}"
        )

    def init_batch_variables(self):
        self.batch_excel_path = tk.StringVar()
        self.batch_layout = tk.StringVar(value=LAYOUT_OPTION_DEFAULT)
        self.batch_output_path = tk.StringVar()
        self.batch_status = None
        self.batch_btn_pdf = None

    # ==== SAMMELVERARBEITUNG ====
    def build_tab_batch(self):
        frame = self.tab_batch

        # Firmenlogo
        self.add_logo_to_frame(frame)

        # Titel
        tk.Label(
            frame,
            text=BATCH_TAB_TITLE_TEXT,
            font=FONT_TITLE,
            bg=BG_COLOR
        ).grid(row=0, column=0, sticky="w", pady=(10, 8), columnspan=2)

        # Layout Dropdown
        tk.Label(
            frame,
            text=BATCH_LAYOUT_LABEL_TEXT,
            font=FONT_LABEL,
            bg=BG_COLOR
        ).grid(row=1, column=0, sticky="w", padx=(0,0))
        layout_dropdown = self.add_layout_combobox(
            frame,
            self.batch_layout,
            row=2,
            pady=(0, 14)
        )
        layout_dropdown.bind("<<ComboboxSelected>>", lambda e: self.update_batch_button())

        # Excel-Dateiauswahl
        tk.Label(frame, text=BATCH_EXCEL_LABEL_TEXT, bg=BG_COLOR).grid(row=3, column=0, sticky="w")
        self.add_text_entry(frame, self.batch_excel_path, row=4, width=60)
        self.add_browse_button(frame, self.browse_batch_excel, row=4)

        # Hinweistext
        tk.Label(
            frame, text=BATCH_HINT_NO_HEADER_TEXT, font=FONT_HINT, fg=HINT_TEXT_COLOR, bg=BG_COLOR
        ).grid(row=5, column=0, sticky="w", pady=(12, 0))
        tk.Label(
            frame, text=BATCH_HINT_COLUMN_A_TEXT, font=FONT_HINT, fg=HINT_TEXT_COLOR, bg=BG_COLOR
        ).grid(row=6, column=0, sticky="w")
        tk.Label(
            frame, text=BATCH_HINT_COLUMN_B_TEXT, font=FONT_HINT, fg=HINT_TEXT_COLOR, bg=BG_COLOR
        ).grid(row=7, column=0, sticky="w")

        # Speicherort Auswahl
        tk.Label(frame, text=BATCH_OUTPUT_LABEL_TEXT, bg=BG_COLOR).grid(row=8, column=0, pady=(16, 0), sticky="w")
        self.add_text_entry(frame, self.batch_output_path, row=9, width=60)
        self.add_browse_button(frame, self.save_batch_pdf, row=9)

        # Status-Label
        self.batch_status = self.add_status_label(frame)
        self.batch_status.grid(row=10, column=0, sticky="w", pady=(14, 0))

        # Buttons
        btn_frame = tk.Frame(frame, bg=BG_COLOR)
        btn_frame.grid(row=11, column=0, columnspan=2, pady=20, sticky="w")

        self.batch_btn_pdf = self.add_create_pdf_button(btn_frame, self.on_batch_generate)
        self.batch_btn_pdf.pack(side="left", padx=(0, 20))

        self.add_support_button(btn_frame)

        # Handbuch-Button unten rechts
        self.add_handbook_button(frame)

        # Live-Validation
        frame.bind_all('<KeyRelease>', lambda e: self.update_batch_button())
        frame.bind_all('<<ComboboxSelected>>', lambda e: self.update_batch_button())

    def update_batch_button(self):
        excel = self.batch_excel_path.get().strip()
        pdf = self.batch_output_path.get().strip()
        zeilen = self.batch_layout.get()
        if is_batch_pdf_valid(excel, pdf, zeilen):
            self.batch_btn_pdf.config(state="normal")
        else:
            self.batch_btn_pdf.config(state="disabled")

    def browse_batch_excel(self):
        path = filedialog.askopenfilename(
            title=EXCEL_DIALOG_TITLE,
            filetypes=[(EXCEL_FILE_TYPE_LABEL, EXCEL_FILE_PATTERN)]
        )
        if path:
            self.batch_excel_path.set(path)
            self.update_batch_button()

    def save_batch_pdf(self):
        path = filedialog.asksaveasfilename(
            defaultextension=PDF_DEFAULT_EXTENSION,
            filetypes=[(PDF_FILE_TYPE_LABEL, PDF_FILE_PATTERN)]
        )
        if path:
            self.batch_output_path.set(path)
            self.update_batch_button()

    def on_batch_generate(self):
        self.batch_status.config(text=STATUS_CREATING_PDF_TEXT)
        self.root.update_idletasks()

        choice = get_line_count_from_layout(self.batch_layout.get())
        excel = self.batch_excel_path.get()
        output = self.batch_output_path.get()

        generate_batch_pdf(excel, output, choice)

        self.batch_status.config(text=STATUS_DONE_TEXT)
        messagebox.showinfo(
            MESSAGEBOX_DONE_TITLE,
            f"{MESSAGEBOX_PDF_CREATED_TEXT}\n{self.batch_output_path.get()}"
        )

    def show_handbuch(self):
        HandbuchWindow(self.root)

    def open_email(self):
        open_support_email()

