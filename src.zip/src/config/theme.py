BG_COLOR = "#9d9d9d"
BUTTON_COLOR = "#00703c"
BUTTON_TEXT_COLOR = "black"

ENTRY_TEXT_COLOR = "black"
ENTRY_CURSOR_COLOR = "black"

GUI_LOGO_PATH = "assets/Logo_trans.png"
GUI_LOGO_WIDTH = 250
GUI_LOGO_HEIGHT = 80
GUI_LOGO_RELX = 1.0
GUI_LOGO_RELY = 0.0
GUI_LOGO_ANCHOR = "ne"
MAIN_WINDOW_GEOMETRY = "810x600"
SEPARATOR_COLOR = "#6e6e6e"
VERSION_LABEL_TEXT = "© Fabian Wiese – Version 1.0 ⓘ"
FONT_TAB = ("Arial", 11, "bold")
FONT_TITLE = ("Arial", 12, "bold")
FONT_LABEL = ("Arial", 10)
FONT_VERSION = ("Arial", 10, "normal")
FONT_VERSION_HOVER = ("Arial", 10, "underline")
FONT_HINT = ("Arial", 9)
HINT_TEXT_COLOR = "darkblue"
APP_WINDOW_TITLE = "Lagerplatz-QRCode-Generator Version 1.0"
TAB_SINGLE_TITLE = "Einzelerstellung"
TAB_BATCH_TITLE = "Sammelverarbeitung"
STATUS_TEXT_COLOR = "blue"
VERSION_TEXT_COLOR = "black"
VERSION_HOVER_TEXT_COLOR = "white"

LAYOUT_OPTION_DEFAULT = "Bitte wählen..."
LAYOUT_OPTION_4_LINES = "4 Zeilen pro PDF-Seite"
LAYOUT_OPTION_5_LINES = "5 Zeilen pro PDF-Seite"

LAYOUT_OPTIONS = [
    LAYOUT_OPTION_DEFAULT,
    LAYOUT_OPTION_4_LINES,
    LAYOUT_OPTION_5_LINES,
]